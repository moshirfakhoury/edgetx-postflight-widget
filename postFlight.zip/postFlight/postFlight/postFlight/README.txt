Post Flight Review Widget (EdgeTX)

Overview:
The Post Flight Review Widget is a powerful EdgeTX Lua widget designed to help pilots analyze and review flight performance after landing. With support for up to 8 telemetry parameters, it captures and displays minimum and maximum values for each assigned sensor or data source. Two of these parameters can also be assigned to logical values, enabling pilots to track switches, arm states, or motor state during the flight. Unlike live telemetry displays, the PFR widget preserves data even if the flight battery is disconnected, allowing for thorough post-flight analysis. All recorded telemetry values reset only when the transmitter is powered off, ensuring a full flight session can be reviewed without interruption. This makes it an essential tool for optimizing flight performance, troubleshooting issues, or simply keeping detailed flight records.

Features:
Supports up to 8 telemetry parameters, showing min and max values for each.
Two parameters can be assigned as logical/binary values for switches, arm states, or custom conditions.
Persistent telemetry data: values remain even if the flight battery is disconnected.
Resets automatically only when the transmitter is switched off.
Provides post-flight insight to help pilots analyze performance, battery usage, signal quality, RPM, temperatures, or any other telemetry data.
Easy configuration through EdgeTX widget parameters for flexible assignment of telemetry sources.
Ideal for flight review, training, troubleshooting, and performance optimization.
Minimalistic, easy-to-read interface designed for quick interpretation of flight data.

## Licence
This project is licensed under the Creative Commons
Attribution-NonCommercial 4.0 International License.
Commercial use is not permitted.