---------------------------------------------------------------------------
-- Post Flight Review Widget
-- EdgeTX 2.11+
-- RAM-only min/max (resets on TX reboot)
---------------------------------------------------------------------------

local name = "postFlight"

---------------------------------------------------------------------------
-- OPTIONS (10 total)
---------------------------------------------------------------------------

local options = {
  { "T1", SOURCE, 0 },
  { "T2", SOURCE, 0 },
  { "T3", SOURCE, 0 },
  { "T4", SOURCE, 0 },
  { "T5", SOURCE, 0 },
  { "T6", SOURCE, 0 },
  { "T7", SOURCE, 0 },
  { "T8", SOURCE, 0 },
  { "S1", SOURCE, 0 },
  { "S2", SOURCE, 0 },
}

---------------------------------------------------------------------------
-- INTERNAL STATE (RAM ONLY)
---------------------------------------------------------------------------

local stats = {}
local initialized = false

---------------------------------------------------------------------------
-- RESET STATS
---------------------------------------------------------------------------

local function resetStats(opts)
  stats = {}
  for i = 1, 8 do
    local src = opts["T" .. i]
    if src ~= 0 then
      local info = getSourceInfo(src)
      if info and info.name then
        stats[info.name] = { min = nil, max = nil }
      end
    end
  end
end

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return {
    zone = zone,
    options = opts or {}
  }
end

local function update(widget, opts)
  widget.options = opts
  initialized = false -- re-init if options change
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  -- Initialize ONCE per TX power-on
  if not initialized then
    resetStats(opt)
    initialized = true
  end

  -------------------------------------------------------------------------
  -- TITLE
  -------------------------------------------------------------------------

  lcd.drawText(
    z.x + z.w / 2,
    z.y + 14,
    "POST FLIGHT REVIEW",
    CENTER + DBLSIZE + WHITE
  )

  -------------------------------------------------------------------------
  -- MODEL CONNECTED (HARD-CODED TO 1RSS)
  -------------------------------------------------------------------------

  local rss = getValue("1RSS")
  local modelConnected = rss ~= nil and rss ~= 0

  -------------------------------------------------------------------------
  -- TABLE LAYOUT
  -------------------------------------------------------------------------

  local rows = 5
  local cols = 2

  local rowH = 30
  local colW = math.floor(z.w * 0.42)
  local gap  = 10

  local tableW = colW * cols + gap
  local tableH = rowH * rows

  local startX = z.x + (z.w - tableW) / 2
  local startY = z.y + 60

  -------------------------------------------------------------------------
  -- TABLE DRAW
  -------------------------------------------------------------------------

  for r = 0, rows - 1 do
    for c = 0, cols - 1 do
      local x = startX + c * (colW + gap)
      local y = startY + r * rowH

      local index = r * 2 + c + 1

      ---------------------------------------------------------------------
      -- T1–T8 TELEMETRY
      ---------------------------------------------------------------------

      if index <= 8 then
        lcd.drawRectangle(x, y, colW, rowH, GREY)

        local src = opt["T" .. index]
        if src ~= 0 then
          local info = getSourceInfo(src)
          if info and info.name then

            local val = getValue(info.name)

            -- Update min/max ONLY when telemetry is valid
            if val ~= nil and val ~= 0 then
              local s = stats[info.name]
              if s then
                if s.min == nil or val < s.min then s.min = val end
                if s.max == nil or val > s.max then s.max = val end
              end
            end

            local minVal = stats[info.name] and stats[info.name].min or 0
            local maxVal = stats[info.name] and stats[info.name].max or 0

            local noDecimals =
              info.name == "1RSS" or
              info.name == "RQly" or
              info.name == "Tesc" or
              info.name == "Tbec" or
              info.name == "RPM"

            local fmt = noDecimals and "%d / %d" or "%.2f / %.2f"

            lcd.drawText(
              x + 6,
              y + 4,
              info.name,
              LEFT + SMLSIZE + GREY
            )

            lcd.drawText(
              x + colW - 6,
              y + 14,
              string.format(fmt, minVal, maxVal),
              RIGHT + SMLSIZE + WHITE
            )
          end
        end

      ---------------------------------------------------------------------
      -- S1 (MOTOR)
      ---------------------------------------------------------------------

      elseif index == 9 and opt.S1 ~= 0 then
        local active = getValue(opt.S1) > 0
        local bgColor = active and RED or GREEN

        lcd.drawFilledRectangle(x, y, colW, rowH, bgColor)
        lcd.drawRectangle(x, y, colW, rowH, WHITE)

        lcd.drawText(
          x + colW / 2,
          y + rowH / 2 - 14,
          active and "MOTOR ON" or "MOTOR OFF",
          CENTER + MIDSIZE + WHITE
        )

      ---------------------------------------------------------------------
      -- S2 (ARM)
      ---------------------------------------------------------------------

      elseif index == 10 and opt.S2 ~= 0 then
        local active = getValue(opt.S2) > 0
        local bgColor = active and RED or GREEN

        lcd.drawFilledRectangle(x, y, colW, rowH, bgColor)
        lcd.drawRectangle(x, y, colW, rowH, WHITE)

        lcd.drawText(
          x + colW / 2,
          y + rowH / 2 - 14,
          active and "ARMED" or "DISARMED",
          CENTER + MIDSIZE + WHITE
        )
      end
    end
  end

  -------------------------------------------------------------------------
  -- BOTTOM STATUS TILE
  -------------------------------------------------------------------------

  local tileH = 32
  local tileY = startY + tableH + 16
  local tileX = z.x + 10
  local tileW = z.w - 20

  if modelConnected then
    lcd.drawFilledRectangle(tileX, tileY, tileW, tileH, RED)
  end

  lcd.drawRectangle(tileX, tileY, tileW, tileH, WHITE)

  lcd.drawText(
    tileX + tileW / 2,
    tileY - 4,
    modelConnected and "MODEL CONNECTED" or "MODEL DISCONNECTED",
    CENTER + DBLSIZE + WHITE
  )
end

---------------------------------------------------------------------------

return {
  name     = name,
  create  = create,
  update  = update,
  refresh = refresh,
  options = options
}
